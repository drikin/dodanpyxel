
        # DodanPyxel - macOS版
        
        ## インストール方法
        1. ダウンロードしたZIPファイルを解凍します。
        2. ターミナルで dodanpyxel.sh を実行します。
           $ chmod +x dodanpyxel.sh
           $ ./dodanpyxel.sh
        
        ## 注意事項
        初回起動時は「開発元を確認できないアプリ」と表示される場合があります。
        Control+クリックで「開く」を選択してください。
        
        ## コントロール
        - 矢印キー: 移動
        - 自動発射モード有効
        - ESC: ゲーム終了
        
        お楽しみください！
        