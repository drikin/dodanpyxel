#!/bin/bash
echo "DodanPyxel をインストールしています..."
python3 -m pip install pyxel
echo "インストール完了！"
python3 main.py
